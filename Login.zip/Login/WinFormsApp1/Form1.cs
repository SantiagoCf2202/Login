namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private int intentos = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string contrase�a = txtContrase�a.Text;

            // Verificar si el usuario y la contrase�a son correctos
            if (usuario == "usuario" && contrase�a == "contrasena")
            {
                MessageBox.Show("Inicio de sesi�n exitoso");
                this.Close();
            }
            else
            {
                intentos++;

                if (intentos == 3)
                {
                    MessageBox.Show("Has alcanzado el n�mero m�ximo de intentos. El formulario se cerrar�.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Nombre de usuario o contrase�a incorrectos. Intentos restantes: " + (3 - intentos));
                }
            }
        }
    }
}