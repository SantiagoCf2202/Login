namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private int intentos = 0;
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Santiago Cano Florez 
        /// 02/05/2023
        /// Preparar un login con la opcion de registrar tambien 
        /// </summary>

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string contrase�a = txtContrase�a.Text;

            // Verificar si el usuario y la contrase�a son correctos con condicional y en el caso de que no mostrar los intentos fallidos
            if (usuario == "usuario" && contrase�a == "contrasena")
            {
                MessageBox.Show("Inicio de sesi�n exitoso");
                this.Close();
            }
            else
            {
                intentos++;

                if (intentos == 3)
                {
                    MessageBox.Show("Has alcanzado el n�mero m�ximo de intentos. El formulario se cerrar�.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Nombre de usuario o contrase�a incorrectos. Intentos restantes: " + (3 - intentos));
                }
            }
        }

        //Creams un nuevo formulario para cuand el usuario seleccione Crear cuenta
        private void btnCrear_Click(object sender, EventArgs e)
        {
            Reagistrar reagistrar = new Reagistrar();
            this.Hide();
            reagistrar.Show();
        }
    }
}